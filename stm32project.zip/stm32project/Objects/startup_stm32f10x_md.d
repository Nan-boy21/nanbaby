.\objects\startup_stm32f10x_md.o: D:\Keil5\ARM\PACK\Keil\STM32F1xx_DFP\2.2.0\Device\Source\ARM\startup_stm32f10x_md.s
