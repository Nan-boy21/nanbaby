
//ʱ�ӼĴ���
#define RCC_BASE        0x40021000U
#define RCC_CR          *((volatile unsigned int *)(RCC_BASE + 0x00))
#define RCC_CFGR        *((volatile unsigned int *)(RCC_BASE + 0x04))
#define RCC_APB2ENR     *((volatile unsigned int *)(RCC_BASE + 0x18))
    
//GPIOA�Ĵ���
#define GPIOA_BASE 0x40010800U       
#define GPIOA_CRL *((volatile unsigned int *)(GPIOA_BASE + 0x00)) 
#define GPIOA_ODR  *((volatile unsigned int *)(GPIOA_BASE + 0x0C))
    
//GPIOB�Ĵ���
#define GPIOB_BASE 0x40010C00U
#define GPIOB_CRL  *((volatile unsigned int *)(GPIOB_BASE + 0x00))
#define GPIOB_ODR  *((volatile unsigned int *)(GPIOB_BASE + 0x0C))


#define GPIOC_BASE 0x40011000U
#define GPIOC_CRH  *((volatile unsigned int *)(GPIOC_BASE + 0x04))
#define GPIOC_ODR  *((volatile unsigned int *)(GPIOC_BASE + 0x0C))

//��ʱ����
void delay_ms(unsigned int t)
{
    volatile unsigned int i,j;
    for(i = t; i > 0; i--)
        for(j = 7200; j > 0; j--);
}


int main(void)
{ 
    //��GPIOA GPIOB ʱ�� APB2ENR bit2 GPIOA bit3 GPIOB
    RCC_APB2ENR |=(1 << 2) | (1 << 3);
    
    //PA0���� 50MHz�������
    GPIOA_CRL &= ~(0xF << (4*0));
    GPIOA_CRL |=  (0x3 << (4*0));
    
    //PB0���� 50MHz�������
    GPIOB_CRL &= ~(0xF << (4*0));
    GPIOB_CRL |=  (0x3 << (4*0));
    
    //PB1���� 50MHz�������
    GPIOB_CRL &= ~(0xF << (4*1));
    GPIOB_CRL |=  (0x3 << (4*1));
    
    while(1){
        //״̬1��PB0 PB1����PA0��
        GPIOA_ODR |=  (1 << 0);
        GPIOB_ODR &= ~((1 << 0) | (1 << 1));
        delay_ms(1000);
        
        //״̬2��PA0 PB1����PB0��
        GPIOA_ODR &= ~(1 << 0);
        GPIOB_ODR |=  (1 << 0);
        GPIOB_ODR &= ~(1 << 1);
        delay_ms(1000);
        
        //״̬3��PA0 PB0����PB1��
        GPIOA_ODR &= ~(1 << 0);
        GPIOB_ODR &= ~(1 << 0) ;
        GPIOB_ODR |=  (1 << 1);
        delay_ms(1000);
    }
}
